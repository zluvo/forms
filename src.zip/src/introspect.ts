export default function introspect(f: Function) {
  return function (formData: FormData) {
    console.log(formData);
    f(formData);
  };
}

export const actions = {
  create: async ({ request }) => {
    console.log(await request.json());
  },
} satisfies Actions;
