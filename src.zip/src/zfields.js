const z = require("zod");

const schema = z.object({
  username: z.string().url(),
});
