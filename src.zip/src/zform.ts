import { z } from "zod";

export const validator = z;

export class field {
  static text(params: {
    label: string;
    placeholder: string;
    value: string;
    validation?: z.ZodString;
  }) {
    return { ...params, defaultValidation: validator.string(), type: "text" };
  }

  static number(params: {
    label: string;
    placeholder: string;
    value: number;
    validation?: z.ZodNumber;
  }) {
    return {
      ...params,
      defaultValidation: validator.coerce.number(),
      type: "number",
    };
  }

  static textArea(params: {
    label: string;
    placeholder: string;
    value: number;
    validation?: z.ZodString;
  }) {
    return {
      ...params,
      defaultValidation: validator.string(),
      type: "textarea",
    };
  }

  static email(params: {
    label: string;
    placeholder: string;
    value: number;
    validation?: z.ZodString;
  }) {
    return {
      ...params,
      defaultValidation: validator.string().email(),
      type: "email",
    };
  }

  static password(params: {
    label: string;
    placeholder: string;
    value: number;
    validation?: z.ZodString;
  }) {
    return {
      ...params,
      defaultValidation: validator.string(),
      type: "password",
    };
  }

  static telephone(params: {
    label: string;
    placeholder: string;
    value: number;
    validation?: z.ZodString;
  }) {
    return {
      ...params,
      defaultValidation: validator
        .string()
        .refine((data) => /^\d{3}-\d{3}-\d{4}$/.test(data), {
          message: "Invalid phone number format.",
        }),
      type: "tel",
    };
  }
}

type Field = {
  label: string;
  placeholder: string;
  type: string;
  value: number | string | boolean;
  defaultValidation: z.ZodString | z.ZodNumber;
  validation?: z.ZodString | z.ZodNumber;
};

type Fields = {
  [name: string]: Field;
};

export class form {
  get names(): string[] {
    if (this.names.length) {
      return this.names;
    } else {
      return Object.keys(this) as string[];
    }
  }
  private set names(value: string[]) {
    this.names = value;
  }

  get fields(): Field[] {
    if (this.fields.length) {
      return this.fields;
    } else {
      return Object.values(this) as Field[];
    }
  }
  private set fields(value: Field[]) {
    this.fields = value;
  }

  static create(fields: Fields) {
    const temp = new form();
    temp.fields = Object.values(fields);
    temp.names = Object.keys(fields);
    return Object.seal(temp);
  }

  consume(formData?: FormData): {
    secure: boolean;
    valid: boolean;
    errors: {
      [name: string]: string[];
    };
    values: (number | boolean | string)[];
  } {
    const errors: {
      [name: string]: string[];
    } = {};
    const values: (number | boolean | string)[] = [];
    this.fields.forEach((field: Field, i: number) => {
      const name = this.names[i];
      if (name) {
        const value = formData?.get(name) || field.value;
        const result = field.defaultValidation.safeParse(value);
        const fieldErrors = new Set<string>();

        // default validation
        if (result.success) {
          field.value = result.data;
        } else {
          const error: z.ZodError = result.error;
          error.issues
            .map((issue) => issue.message)
            .forEach((error) => fieldErrors.add(error));
        }

        // extra validation
        if (field.validation) {
          const result = field.validation.safeParse(value);
          if (result.success) {
            field.value = result.data;
          } else {
            const error: z.ZodError = result.error;
            error.issues
              .map((issue) => issue.message)
              .forEach((error) => fieldErrors.add(error));
          }
        }

        if (fieldErrors.size) {
          errors[name] = Array.from(fieldErrors);
        } else {
          values.push(field.value);
        }
      }
    });

    const valid = Object.keys(errors).length == 0;
    return {
      secure: true,
      valid: valid,
      errors: errors,
      values: valid ? values : [],
    };
  }
}

export const f = form.create({
  username: field.text({
    label: "Username",
    placeholder: "Your Username",
    value: "something",
    validation: validator.string().min(1),
  }),
  age: field.number({
    label: "Age",
    placeholder: "Your age",
    value: 7,
    validation: validator.number().min(1),
  }),
});
